# АгроРасчёт — Android project

This project builds a debug APK in GitHub Actions. No Android Studio is required on the user's computer.

## Cloud build
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository (not the enclosing folder).
3. Open the Actions tab and enable workflows if asked.
4. Select **Build AgroRaschet APK** → **Run workflow**.
5. When the run finishes successfully, open it and download the **AgroRaschet-debug-APK** artifact. Unzip it to get `app-debug.apk`.

This is an unsigned debug APK intended for personal testing, not a Play Store release.
